import React, { useState } from 'react';
import './bejelentkezes.css';

function Bejelentkezes({ navigateTo }) {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    remember: false
  });

  const [formErrors, setFormErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    
    // Clear error for this field when user starts typing
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: ''
      });
    }
  };

  const validateForm = () => {
    const errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Email validation
    if (!formData.email) {
      errors.email = 'Az email cím megadása kötelező';
    } else if (!emailRegex.test(formData.email)) {
      errors.email = 'Érvényes email címet adjon meg';
    }

    // Password validation
    if (!formData.password) {
      errors.password = 'A jelszó megadása kötelező';
    } else if (formData.password.length < 6) {
      errors.password = 'A jelszónak legalább 6 karakter hosszúnak kell lennie';
    }

    return errors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const errors = validateForm();
    
    if (Object.keys(errors).length === 0) {
      setIsLoading(true);
      
      // Simulate API call delay
      setTimeout(() => {
        // Get registered users from localStorage
        const registeredUsers = JSON.parse(localStorage.getItem('powerplan_users') || '[]');
        
        // Check if user exists
        const user = registeredUsers.find(u => u.email === formData.email);
        
        if (user) {
          // In a real app, we would check the password hash
          // For demo purposes, we'll accept any password
          
          // Save login state
          localStorage.setItem('powerplan_current_user', JSON.stringify(user));
          localStorage.setItem('powerplan_user_logged_in', 'true');
          localStorage.setItem('powerplan_user_completed_questionnaire', 'true');
          
          if (formData.remember) {
            localStorage.setItem('powerplan_remember_me', 'true');
            localStorage.setItem('powerplan_remembered_email', formData.email);
          }
          
          // Show success message
          alert('Sikeres bejelentkezés! Üdvözöljük újra!');
          
          // Redirect to home page
          if (navigateTo) {
            navigateTo('home');
          } else {
            window.location.href = '/';
          }
        } else {
          setFormErrors({
            general: 'Hibás email cím vagy jelszó'
          });
        }
        
        setIsLoading(false);
      }, 1500);
    } else {
      setFormErrors(errors);
    }
  };

  const handleForgotPassword = (e) => {
    e.preventDefault();
    alert('Jelszó visszaállítási link elküldve az email címére.');
  };

  const handleSocialLogin = (provider) => {
    alert(`${provider} bejelentkezés - Ez a funkció jelenleg fejlesztés alatt van`);
  };

  return (
    <div className="bejelentkezes-container">
      {/* Navigáció */}
   

      {/* Bejelentkezési űrlap */}
      <div className="form-container">
        <div className="form-box">
          <h2>Bejelentkezés</h2>
          <p>Add meg az adataidat a belépéshez</p>
          
          {formErrors.general && (
            <div className="error-message general-error">
              <i className="fas fa-exclamation-circle"></i>
              {formErrors.general}
            </div>
          )}
          
          <form id="loginForm" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email cím</label>
              <div className="input-with-icon">
                <i className="fas fa-envelope"></i>
                <input 
                  type="email" 
                  id="email" 
                  name="email"
                  placeholder="email.cim@pelda.hu" 
                  value={formData.email}
                  onChange={handleInputChange}
                  className={formErrors.email ? 'input-error' : ''}
                />
              </div>
              {formErrors.email && <span className="error-message">{formErrors.email}</span>}
            </div>
            
            <div className="form-group">
              <label htmlFor="password">Jelszó</label>
              <div className="input-with-icon">
                <i className="fas fa-lock"></i>
                <input 
                  type="password" 
                  id="password" 
                  name="password"
                  placeholder="Add meg a jelszavad" 
                  value={formData.password}
                  onChange={handleInputChange}
                  className={formErrors.password ? 'input-error' : ''}
                />
              </div>
              {formErrors.password && <span className="error-message">{formErrors.password}</span>}
            </div>
            
            <div className="form-options">
              <div className="remember-me">
                <input 
                  type="checkbox" 
                  id="remember" 
                  name="remember"
                  checked={formData.remember}
                  onChange={handleInputChange}
                />
                <label htmlFor="remember">Emlékezz rám</label>
              </div>
              <a href="#" className="forgot-password" onClick={handleForgotPassword}>
                Elfelejtetted a jelszavad?
              </a>
            </div>
            
            <button type="submit" className="submit-button" disabled={isLoading}>
              {isLoading ? (
                <>
                  <i className="fas fa-spinner fa-spin"></i> BEJELENTKEZÉS...
                </>
              ) : (
                'BEJELENTKEZÉS'
              )}
            </button>
          </form>
          
          <div className="divider">
            <span>VAGY</span>
          </div>
          
          <div className="social-login">
            <button className="social-button facebook" onClick={() => handleSocialLogin('Facebook')}>
              <i className="fab fa-facebook-f"></i>
            </button>
            <button className="social-button google" onClick={() => handleSocialLogin('Google')}>
              <i className="fab fa-google"></i>
            </button>
            <button className="social-button apple" onClick={() => handleSocialLogin('Apple')}>
              <i className="fab fa-apple"></i>
            </button>
          </div>
          
          <div className="form-footer">
            Még nincs fiókod? <a href="#" onClick={() => navigateTo('regisztracio')}>Regisztrálj most!</a>
          </div>
        </div>
      </div>

      {/* Lábléc */}
      <footer>
        <div className="footer-content">
          <div className="footer-column">
            <h3>Power Plan</h3>
            <p>Edzőtermi alkalmazás, amely segít elérni fitness céljaidat. Éld át a változást velünk!</p>
          </div>
          <div className="footer-column">
            <h3>Gyors linkek</h3>
            <ul className="footer-links">
              <li><a href="#" onClick={() => navigateTo('home')}>Kezdőlap</a></li>
              <li><a href="#" onClick={() => navigateTo('home')}>Szolgáltatások</a></li>
              <li><a href="#" onClick={() => navigateTo('home')}>Rólunk</a></li>
              <li><a href="#" onClick={() => navigateTo('home')}>Árak</a></li>
              <li><a href="#" onClick={() => navigateTo('home')}>Kapcsolat</a></li>
            </ul>
          </div>
          <div className="footer-column">
            <h3>Kövess minket</h3>
            <div className="social-icons">
              <a href="#"><i className="fab fa-facebook-f"></i></a>
              <a href="#"><i className="fab fa-instagram"></i></a>
              <a href="#"><i className="fab fa-youtube"></i></a>
              <a href="#"><i className="fab fa-tiktok"></i></a>
            </div>
          </div>
        </div>
        <div className="copyright">
          <p>&copy; 2023 Power Plan Edzőtermi Alkalmazás. Minden jog fenntartva.</p>
        </div>
      </footer>
    </div>
  );
}

export default Bejelentkezes;