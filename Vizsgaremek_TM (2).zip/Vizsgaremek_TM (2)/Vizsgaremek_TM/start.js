const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

console.log('='.repeat(50));
console.log('🚀 POWERPLAN FITNESS APP - START');
console.log('='.repeat(50));

// Színek konzolhoz
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  yellow: '\x1b[33m',
  red: '\x1b[1;31m'
};

// Ellenőrzések
console.log('\n📋 Előzetes ellenőrzések...');

// 1. Docker elérhető?
try {
  spawn('docker', ['--version'], { stdio: 'ignore' });
  console.log(`${colors.green}✓${colors.reset} Docker elérhető`);
} catch {
  console.log(`${colors.red}✗${colors.reset} Docker nincs telepítve!`);
  process.exit(1);
}

// 2. Frontend package.json létezik?
const frontendPackagePath = path.join(__dirname, 'Frontend', 'package.json');
if (!fs.existsSync(frontendPackagePath)) {
  console.log(`${colors.red}✗${colors.reset} Frontend/package.json nem található!`);
  process.exit(1);
}
console.log(`${colors.green}✓${colors.reset} Frontend/package.json megtalálva`);

// 3. Backend projekt létezik?
const backendCsproj = path.join(__dirname, 'Backend', 'PowerPlan.Api.csproj');
if (!fs.existsSync(backendCsproj)) {
  console.log(`${colors.yellow}⚠${colors.reset} Backend projekt nem található, létrehozom...`);
  // Itt hozzáadhatsz automatikus létrehozást ha szeretnéd
}

console.log('\n🎯 Szolgáltatások indítása...\n');

// Process-ek tárolása
const processes = [];

// 1. ADATBÁZIS (Docker Compose)
console.log(`${colors.blue}[1/3]${colors.reset} 🗄️  MySQL adatbázis indítása...`);
const dbProcess = spawn('docker-compose', ['up', 'db'], {
  cwd: __dirname,
  stdio: 'pipe'
});

dbProcess.stdout.on('data', (data) => {
  const output = data.toString();
  if (output.includes('healthy') || output.includes('ready for connections')) {
    console.log(`${colors.green}✓${colors.reset} Adatbázis készen áll`);
  }
  process.stdout.write(`${colors.blue}[DB]${colors.reset} ${output}`);
});

dbProcess.stderr.on('data', (data) => {
  process.stderr.write(`${colors.red}[DB ERROR]${colors.reset} ${data}`);
});

processes.push(dbProcess);

// 2. BACKEND (.NET) - 5 másodperc múlva
setTimeout(() => {
  console.log(`\n${colors.magenta}[2/3]${colors.reset} 🖥️  Backend indítása (.NET 8)...`);
  
  const backendProcess = spawn('dotnet', ['run'], {
    cwd: path.join(__dirname, 'Backend'),
    stdio: 'pipe',
    shell: true
  });

  backendProcess.stdout.on('data', (data) => {
    const output = data.toString();
    if (output.includes('Now listening on:')) {
      console.log(`${colors.green}✓${colors.reset} Backend API elindult`);
    }
    process.stdout.write(`${colors.magenta}[API]${colors.reset} ${output}`);
  });

  backendProcess.stderr.on('data', (data) => {
    process.stderr.write(`${colors.red}[API ERROR]${colors.reset} ${data}`);
  });

  processes.push(backendProcess);
}, 5000);

// 3. FRONTEND (Vite) - 10 másodperc múlva
setTimeout(() => {
  console.log(`\n${colors.cyan}[3/3]${colors.reset} 🌐 Frontend indítása (Vite)...`);
  
  const frontendProcess = spawn('npm', ['run', 'dev'], {
    cwd: path.join(__dirname, 'Frontend'),
    stdio: 'pipe',
    shell: true
  });

  frontendProcess.stdout.on('data', (data) => {
    const output = data.toString();
    if (output.includes('Local:')) {
      console.log(`${colors.green}✓${colors.reset} Frontend kész`);
    }
    process.stdout.write(`${colors.cyan}[FRONT]${colors.reset} ${output}`);
  });

  frontendProcess.stderr.on('data', (data) => {
    process.stderr.write(`${colors.red}[FRONT ERROR]${colors.reset} ${data}`);
  });

  processes.push(frontendProcess);
}, 10000);

// Indítási információk
setTimeout(() => {
  console.log('\n' + '='.repeat(50));
  console.log('✅ MINDEN SZOLGÁLTATÁS ELINDÍTVA!');
  console.log('='.repeat(50));
  console.log('\n📡 ELÉRHETŐ SZOLGÁLTATÁSOK:');
  console.log(`${colors.cyan}• Frontend:${colors.reset}    http://localhost:5173`);
  console.log(`${colors.magenta}• Backend API:${colors.reset} http://localhost:8080`);
  console.log(`${colors.blue}• phpMyAdmin:${colors.reset}   http://localhost:8081`);
  console.log(`${colors.yellow}• MySQL:${colors.reset}       localhost:3306 (root/rootpw)`);
  console.log('\n👨‍💻 HASZNÁLAT:');
  console.log('• API végpontok: http://localhost:8080/api/[controller]');
  console.log('• Adatbázis kezelés: phpMyAdmin (http://localhost:8081)');
  console.log('\n🛑 LEÁLLÍTÁS: Ctrl+C megnyomása');
  console.log('='.repeat(50));
}, 12000);

// CTRL+C kezelése
process.on('SIGINT', () => {
  console.log(`\n${colors.yellow}⏹️  Leállítás...${colors.reset}`);
  
  // Process-ek leállítása
  processes.forEach(proc => {
    if (!proc.killed) {
      proc.kill('SIGINT');
    }
  });
  
  // Docker compose leállítása
  spawn('docker-compose', ['down'], {
    cwd: __dirname,
    stdio: 'inherit'
  });
  
  console.log(`${colors.green}✅ Minden szolgáltatás leállítva.${colors.reset}`);
  process.exit(0);
});

// Hibakezelés
process.on('uncaughtException', (error) => {
  console.log(`${colors.red}❌ Hiba történt:${colors.reset}`, error.message);
  process.exit(1);
});