using Microsoft.EntityFrameworkCore;
using PowerPlan.Models;

namespace PowerPlan.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        
        public DbSet<UserSettings> UserSettings { get; set; }
        public DbSet<Workout> Workouts { get; set; }
        public DbSet<UserExercise> UserExercises { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            // UserSettings konfiguráció
            modelBuilder.Entity<UserSettings>()
                .Property(u => u.MeasurementUnit)
                .HasDefaultValue("metric");
                
            modelBuilder.Entity<UserSettings>()
                .Property(u => u.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP");
                
            modelBuilder.Entity<UserSettings>()
                .Property(u => u.UpdatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .ValueGeneratedOnAddOrUpdate();
                
            // Workout konfiguráció
            modelBuilder.Entity<Workout>()
                .Property(w => w.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP");
                
            // Kapcsolatok
            modelBuilder.Entity<UserExercise>()
                .HasOne(e => e.Workout)
                .WithMany()
                .HasForeignKey(e => e.WorkoutId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}