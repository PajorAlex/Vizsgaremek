using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerPlan.Models
{
    public class Workout
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;
        
        [Required]
        [Column(TypeName = "varchar(20)")]
        public string Type { get; set; } = string.Empty;
        
        [Required]
        [Column(TypeName = "varchar(20)")]
        public string DayOfWeek { get; set; } = string.Empty;
        
        public int Duration { get; set; }
        public bool Completed { get; set; } = false;
        
        public DateTime? CompletedAt { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}