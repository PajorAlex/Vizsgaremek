using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerPlan.Models
{
    public class UserExercise
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public int WorkoutId { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;
        
        public int Sets { get; set; }
        
        [MaxLength(20)]
        public string Reps { get; set; } = string.Empty;
        
        [Column(TypeName = "decimal(5,2)")]
        public decimal? Weight { get; set; }
        
        [ForeignKey("WorkoutId")]
        public Workout? Workout { get; set; }
    }
}