using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerPlan.Models
{
    public class UserSettings
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        public bool NotificationEnabled { get; set; } = true;
        public bool DataMode { get; set; } = true;
        
        [Column(TypeName = "varchar(20)")]
        public string MeasurementUnit { get; set; } = "metric";
        
        public TimeSpan? WorkunitReminderTime { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}